Open The Main Code file in a suitable editor and run the code to play the game!
Enjoy!
